//
//  BinaryTestFramework.h
//  BinaryTestFramework
//
//  Created by Vlastimir Radojevic on 11/1/22.
//

#import <Foundation/Foundation.h>

//! Project version number for BinaryTestFramework.
FOUNDATION_EXPORT double BinaryTestFrameworkVersionNumber;

//! Project version string for BinaryTestFramework.
FOUNDATION_EXPORT const unsigned char BinaryTestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BinaryTestFramework/PublicHeader.h>


